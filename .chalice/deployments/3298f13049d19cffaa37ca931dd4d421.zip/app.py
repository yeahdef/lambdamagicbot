from chalice import Chalice
import requests
GATHERER_TYPEAHEAD_URI = 'http://gatherer.wizards.com/Handlers/InlineCardSearch.ashx?nameFragment=%s'
GATHERER_URI = 'http://gatherer.wizards.com/Handlers/Image.ashx?type=card'

app = Chalice(app_name='cardbot')

@app.route('/')
def index():
  return {'hello': 'world'}

@app.route('/hello/{name}')
def hello_name(name):
  # '/hello/james' -> {"hello": "james"}
  {'hello': name}

@app.route('/magic-cards/', methods=['POST'])
def get_card():
  # This is the JSON body the user sent in their POST request.
  json = app.json_body
  # retrieve card information
  card_name = urllib.quote_plus(request.data['text'])
  # try to derive the card name from a fragment
  cards_json = requests.get(GATHERER_TYPEAHEAD_URI % card_name).json()
  if len(cards_json['Results']) > 0:
    card_name = cards_json['Results'][0]['Name']
    # Catch Slack's garbage /u2019 in the name of Manor Skeleton
    try:
      card_name = card_name.decode('utf-8').replace(u'\u2019', u'\'')
    except Exception as e:
      print e

    # Assign aliases
    if card_name.lower() in CARD_ALIASES:
      card_name = CARD_ALIASES[card_name.lower()]

    # Get card image uri
    response = '{}&name={}'.format(GATHERER_URI, urllib.quote_plus(card_name))
    return Response({
      "response_type": "in_channel",
      "attachments": [
        {
          "text": request.data['text'],
          "image_url": response,
        }
      ]
    })
  else:
    return Response({"text": "Card not found"})